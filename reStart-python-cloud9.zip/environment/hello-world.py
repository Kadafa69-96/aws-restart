print("Hello Weh Mzenga")
