myString = "This is a string nigga."
print(myString)

print(type(myString))
print(myString + " is of the data type " + str(type(myString)))

firstString= "water"
secondString= "fall"
thirdrdString= firstString + secondString
print(thirdrdString)

name = input("what is your name? ")
print(name)

color = input("What is your fav color? ")
animal = input("What is yout fav animal? ")
print("{}, you like a {} {}! ".format(name,color,animal))
